# Colver-EFI-K670C G4E1
#处理器改为：i5-8500，显卡为：UHD630
#目前只有外接显示器不能使用，其他功能正常（已知：外接HDMI显示器会死机，VGA接口没试过）
修改默认启动盘符：<key>DefaultVolume</key><string>LastBootedVolume</string> 将【LastBootedVolume】修改为盘符名称即可；

修改等待时间：<key>Timeout</key><integer>5</integer> 其中<integer>5</integer>里面的5表示等待5秒，可修改成其他数字；

开启详细日志模式：
<key>Arguments</key>
	<string>dart=0 -v -lilubetaall slide=0 keepsyms=1 debug=0x100 -no_compat_check</string>
